## include libraries
library(stringr)
library(tidyr)
library(ggplot2)
library(gridExtra)

## read the csv
uber <- read.csv("Uber Request Data.csv",stringsAsFactors = F)

## Separate Date and Time using Timestamp which is suitable for analysis for Request Timestamp
uber <- separate(uber, Request.timestamp,into=c('R.date','R.time'),sep=" ",remove = F)

## 1. Date Quality issue - There two mixed format for date
## Making date format identical
uber$R.date <- gsub("/", "-", uber$R.date)

## 2. Data Quality issue - Leading 0 for each month(but month not neededfor analysis)
## uber$R.month <- gsub("^0", "", uber$R.month)

## Separate Reques Time to Hours, mins and seconds for suitable analysis
uber <- separate(uber, R.time,into=c('R.hour','R.mins','R.sec'),sep=":",remove = F)

## 3. Data Quality issue - Making identical leading 0 for requested hour
uber$R.hour <- sprintf("%02d", as.numeric(uber$R.hour))

## Question-1 Visually identify the most pressing problems for Uber(Graph1). 
ggplot(subset(uber, Status %in% c("Cancelled", "No Cars Available")), aes(x=R.hour, fill=Status)) +geom_bar()+facet_wrap(~Pickup.point)

## The most pressing problem can be seen from the Graph1 which shows the large number of incompleted trips during morning and evening peak hours

## Question-2 Find out the gap between supply and demand and show the same using plots.
## Creating two subset for completed trips and incompleted trips
compTrips <- subset(uber, Status %in% c("Trip Completed"))
incompTrips <- subset(uber, Status %in% c("Cancelled", "No Cars Available"))

## Creating each subset for complete and incomplete trips based on Pick up point
incompTripsAirport <- subset(incompTrips, Pickup.point %in% c("Airport"))
incompTripsCity <- subset(incompTrips, Pickup.point %in% c("City"))
compTripsCity <- subset(compTrips, Pickup.point %in% c("City"))
compTripsAirport <- subset(compTrips, Pickup.point %in% c("Airport"))

## Finding out the time slots when the highest gap exists
## Aggregate Complete and Incomplete Trips based on Time slot
compTrips <- aggregate(compTrips$R.hour, by=list(hour=compTrips$R.hour), FUN=length)
incompTrips <- aggregate(incompTrips$R.hour, by=list(hour=incompTrips$R.hour), FUN=length)

## Renaming Columns
colnames(compTrips)[match("x",colnames(compTrips))] <- "Complete Trips"
colnames(incompTrips)[match("x",colnames(incompTrips))] <- "Incomplete Trips"

## Merge both complted and Incomplete trip dtaframe into onw based on time slot
Trips <- merge(compTrips,incompTrips,by="hour")

## Finding out the gap and removing the two dataframes from memory
Trips$Gap <- Trips$`Complete Trips` - Trips$`Incomplete Trips`
rm(compTrips,incompTrips)

## Plotting the gap for time slot(Graph2)
ggplot(Trips, aes(x=hour,y=Gap)) +geom_col() + ggtitle('Gap Trips')

## The negative bars shows the gap of demand and supply
## The gap is high for morning and evening peak hours
## The gap is higher for evening peak hours(17:00 to 21:00) than morning peak hours(5:00 to 9:00)

## Finding out the type of requests for which the gap is the most severe in the identified time slots

## Aggregating Airport to City Incomplete Trips based on time slots
incompTripsAirport <- aggregate(incompTripsAirport$R.hour, by=list(hour=incompTripsAirport$R.hour), FUN=length)
colnames(incompTripsAirport)[match("x",colnames(incompTripsAirport))] <- "Incomplete Trips"
## Aggregating Airport to City Complete Trips based on time slots
compTripsAirport <- aggregate(compTripsAirport$R.hour, by=list(hour=compTripsAirport$R.hour), FUN=length)
colnames(compTripsAirport)[match("x",colnames(compTripsAirport))] <- "Complete Trips"
## Merge to form Airport To City Trip Dataframe
airportTrips <- merge(compTripsAirport,incompTripsAirport,by="hour")
## Removing Unwanted Dataframes
rm(compTripsAirport,incompTripsAirport)


## Similarly aggregating City to Airports Incomplete Trips based on tim slots
incompTripsCity <- aggregate(incompTripsCity$R.hour, by=list(hour=incompTripsCity$R.hour), FUN=length)
colnames(incompTripsCity)[match("x",colnames(incompTripsCity))] <- "Incomplete Trips"
## Similarly aggregating City to Airports complete Trips based on tim slots
compTripsCity <- aggregate(compTripsCity$R.hour, by=list(hour=compTripsCity$R.hour), FUN=length)
colnames(compTripsCity)[match("x",colnames(compTripsCity))] <- "Complete Trips"
## Merge to form City TO Airport Trip Dataframe
cityTrips <- merge(compTripsCity,incompTripsCity,by="hour")
## Removing unwanted dataframe
rm(compTripsCity,incompTripsCity)

## Finding out the gap for both pick up points dataframe
airportTrips$Gap <- airportTrips$`Complete Trips` - airportTrips$`Incomplete Trips`
cityTrips$Gap <- cityTrips$`Complete Trips` - cityTrips$`Incomplete Trips`

## Plot the graph for both the pick up points(Graph3)
plotCity <- ggplot(cityTrips, aes(x=hour,y=Gap)) +geom_col() + ggtitle('City To Airport Trips')
plotAirports <- ggplot(airportTrips, aes(x=hour,y=Gap)) +geom_col() + ggtitle('Airport To City Trips')
## Removing unwanted dataframes
rm(airportTrips,cityTrips)
grid.arrange(plotCity, plotAirports, nrow=1, ncol=2)
## From Graph2 we can conlude that gap for evening peak hours is greater than morning peak hours
## Graph3 shows that evening gap is for Airport To City Trips

## What do you think is the reason for this issue for the supply-demand gap?
## From Graph2 it can be infer that demand and supply gap is higher for morning peak hours and evening peak hours (5:00 to 9:00 and 17:00 to 21:00)
## From Graph3 it can be infer that morning peak hour gap is from City to Airport
## And eveinng peak hour gap is from Airport to City
## Reason-1 From Graph1 it can be infer that higher rate for Incompeted Trips from Airport to City in Evening peak hours 
## is due to the fact that more flights landed but only a few flights are taking off at evening hours
## So a large part of incomplete trip is due to the No Cars Availability
## Reason-2 The higher rate for Incompleted Trips from City to Airport in morning hours
## is due to the fact that denial of the cab drivers as they obviuosly dont want to trip back to city without any passenger
## and have to wait for next flight(more than few hour(huge variant)) for the next passenger
## and he would have make more money if he is outside the airport that time

## Recommend some ways to resolve the supply-demand gap.
## Solution-1 -> There should be a separate set of airport dedicted cabs which works majorly on
## Airport to City Trips in evening hours and City to Airport in morning hours
## These dedicated cabs should not be used for Airport to City in Morning time and City to Airport in evening.
## Solution-2 -> The cab driver should have been provided the flight schedule so that they wont deny the cab more oftenly

